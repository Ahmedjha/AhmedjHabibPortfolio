document.addEventListener('DOMContentLoaded', () => {
    // Projects Data
    const projects = [
        {
            title: "E-commerce Platform",
            description: "A modern e-commerce solution built with React and Node.js",
            tech: ["React", "Node.js", "MongoDB"],
            image: "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d"
        },
        {
            title: "Weather App",
            description: "Real-time weather application with beautiful UI",
            tech: ["React", "OpenWeather API", "TailwindCSS"],
            image: "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b"
        },
        {
            title: "Task Manager",
            description: "Productivity tool for managing daily tasks",
            tech: ["TypeScript", "React", "Firebase"],
            image: "https://images.unsplash.com/photo-1518770660439-4636190af475"
        },
        {
            title: "Portfolio Website",
            description: "Personal portfolio website with modern design",
            tech: ["React", "TailwindCSS", "Framer Motion"],
            image: "https://images.unsplash.com/photo-1470813740244-df37b8c1edcb"
        }
    ];

    // Populate Projects
    const projectsGrid = document.querySelector('.projects-grid');
    projects.forEach(project => {
        const projectElement = document.createElement('div');
        projectElement.className = 'project-card';
        projectElement.innerHTML = `
            <img src="${project.image}" alt="${project.title}">
            <div class="project-info">
                <h3>${project.title}</h3>
                <p>${project.description}</p>
                <div class="tech-stack">
                    ${project.tech.map(tech => `<span class="tech-tag">${tech}</span>`).join('')}
                </div>
            </div>
        `;
        projectsGrid.appendChild(projectElement);
    });

    // Smooth Scroll
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Form Handling
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = {
                name: this.querySelector('#name').value,
                email: this.querySelector('#email').value,
                message: this.querySelector('#message').value
            };

            // Simulate form submission
            console.log('Form submitted:', formData);
            alert('Thanks for your message! I\'ll get back to you soon.');
            
            // Reset form
            this.reset();
        });
    }

    // Intersection Observer for animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: "0px 0px -50px 0px"
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = "1";
                entry.target.style.transform = "translateY(0)";
            }
        });
    }, observerOptions);

    // Observe all sections
    document.querySelectorAll('section').forEach(section => {
        section.style.opacity = "0";
        section.style.transform = "translateY(20px)";
        section.style.transition = "opacity 0.6s ease-out, transform 0.6s ease-out";
        observer.observe(section);
    });
});
